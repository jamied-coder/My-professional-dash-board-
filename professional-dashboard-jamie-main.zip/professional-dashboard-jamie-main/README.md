# Samsung OQA Operations Dashboard

A web-based Operations Quality Assurance (OQA) dashboard designed for Samsung manufacturing environments.

## Features

### Executive Dashboard
- Real-time KPI Monitoring
- Pass Rate Tracking
- Failed Wafer Tracking
- Open Hold Lots
- Open PRAs
- Tool Status Monitoring

### Shift Management
- Shift A Operations
- Shift B Operations
- Shift C Operations
- Shift D Operations
- Shift Pass-Down Tracking

### Quality Metrics
- Wafer Pass/Fail Analysis
- Production Goal vs Actual
- Lot Tracking
- Quality Trends

### OQA Inventory
- QARS Tracking
- Hold Lots Tracking
- STR Tracking
- Black Mushroom Tracking

### Safety
- Daily Safety Reminders
- Incident Tracking
- Safety Notes
- Compliance Monitoring

### Maintenance
- Tool Status
- Downtime Tracking
- PM Tracking
- Restart Requests

### Reporting
- Daily Shift Reports
- Management Reports
- Email Report Generation

---

## Technology

- HTML5
- CSS3
- JavaScript
- GitHub Pages

---

## Dashboard Views

### Technician View
Technicians can:

- Enter Lot IDs
- Record Passed Wafers
- Record Failed Wafers
- Enter Safety Notes
- Submit Shift Pass-Downs
- Track Tool Issues

### Manager View
Managers can:

- Monitor KPIs
- Approve Pass-Downs
- Review Production Metrics
- Review Safety Data
- Generate Reports

---

## Key Metrics

| Metric | Description |
|----------|------------|
| Pass Rate | Overall Production Yield |
| Lots Processed | Daily Lot Count |
| Failed Wafers | Daily Defect Count |
| Hold Lots | Lots Awaiting Review |
| QARS | Quality Alert Tracking |
| STR | Special Tracking Requests |
| Tool Issues | Equipment Problems |

---

## Deployment

1. Create Repository
2. Upload index.html
3. Upload README.md
4. Enable GitHub Pages
5. Access Dashboard URL

---

## Author

Jamie Dudley Jr

Samsung OQA Operations Dashboard Project

Version 1.0
